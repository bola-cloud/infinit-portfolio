<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card p-4">
        <h2><?php echo e(__('lang.add_service')); ?></h2>
        <form action="<?php echo e(route('admin.services.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label class="form-label"><?php echo e(__('lang.title_en')); ?></label>
                <input type="text" name="en_title" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label"><?php echo e(__('lang.title_ar')); ?></label>
                <input type="text" name="ar_title" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label"><?php echo e(__('lang.description_en')); ?></label>
                <textarea name="en_description" class="form-control" required></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label"><?php echo e(__('lang.description_ar')); ?></label>
                <textarea name="ar_description" class="form-control" required></textarea>
            </div>
            <button type="submit" class="btn btn-success"><?php echo e(__('lang.save')); ?></button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\ictc\resources\views/admin/services/create.blade.php ENDPATH**/ ?>