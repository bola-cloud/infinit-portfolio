<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card p-3">
        <div class="card-header d-flex justify-content-between">
            <h1><?php echo e(__('lang.gallery_management')); ?></h1>
            <a href="<?php echo e(route('admin.galleries.create')); ?>" class="btn btn-primary"><?php echo e(__('lang.create_gallery')); ?></a>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table class="table">
            <thead>
                <tr>
                    <th><?php echo e(__('lang.title')); ?></th>
                    <th><?php echo e(__('lang.type')); ?></th>
                    <th><?php echo e(__('lang.featured_image')); ?></th>
                    <th><?php echo e(__('lang.actions')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e(app()->getLocale() === 'ar' ? $gallery->ar_title : $gallery->en_title); ?></td>
                    <td><?php echo e(__('lang.types.' . $gallery->type)); ?></td>
                    <td>
                        <?php if($gallery->featured_image_id && $gallery->featuredImage): ?>
                            <?php if($gallery->type == 'photo'): ?>
                                <a href="javascript:void(0)"
                                   data-bs-toggle="modal"
                                   data-bs-target="#mediaModal"
                                   data-content="<img src='<?php echo e(asset('storage/' . $gallery->featuredImage->image_path)); ?>' class='img-fluid'>">
                                    <img src="<?php echo e(asset('storage/' . $gallery->featuredImage->image_path)); ?>"
                                         alt="<?php echo e($gallery->featuredImage->ar_subtitle); ?>"
                                         width="100"
                                         height="50">
                                </a>
                            <?php else: ?>
                                <a href="javascript:void(0)"
                                   data-bs-toggle="modal"
                                   data-bs-target="#mediaModal"
                                   data-content="<video src='<?php echo e(asset('storage/' . $gallery->featuredImage->image_path)); ?>' controls class='w-100'></video>">
                                    <video src="<?php echo e(asset('storage/' . $gallery->featuredImage->image_path)); ?>" controls width="100"></video>
                                </a>
                            <?php endif; ?>
                        <?php else: ?>
                            <span><?php echo e(__('lang.no_featured_image')); ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.gallery_images.index', $gallery->id)); ?>" class="btn btn-primary"><?php echo e(__('lang.media_gallery')); ?></a>
                        <a href="<?php echo e(route('admin.galleries.edit', $gallery->id)); ?>" class="btn btn-warning"><?php echo e(__('lang.edit_gallery')); ?></a>
                        <form action="<?php echo e(route('admin.galleries.destroy', $gallery->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger"><?php echo e(__('lang.delete_gallery')); ?></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4"><?php echo e(__('lang.no_galleries_found')); ?></td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal -->
<?php echo $__env->make('partials.media_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\ictc\resources\views/admin/galleries/index.blade.php ENDPATH**/ ?>