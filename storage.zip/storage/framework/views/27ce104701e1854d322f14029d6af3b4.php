<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card p-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h2 class="fw-bold"><?php echo e(__('lang.website_settings')); ?></h2>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success mt-3"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.settings.update')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <!-- Logo Upload -->
            <div class="form-group mt-3">
                <label><?php echo e(__('lang.logo')); ?></label><br>
                <?php if(!empty($settings->logo)): ?>
                    <div style="display: inline-block; padding: 10px; background-color: #f1f1f1; border-radius: 8px;">
                        <img src="<?php echo e(asset($settings->logo)); ?>" width="150" alt="<?php echo e(__('lang.logo')); ?>">
                    </div>
                <?php else: ?>
                    <p><?php echo e(__('lang.no_logo')); ?></p>
                <?php endif; ?>
                <input type="file" name="logo" class="form-control mt-2" accept=".jpeg,.jpg,.png,.gif,.webp">
                <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Cover Image Upload -->
            <div class="form-group mt-3">
                <label><?php echo e(__('lang.cover_image')); ?></label><br>
                <?php if(!empty($settings->cover_image)): ?>
                    <div style="display: inline-block; padding: 10px; background-color: #222; border-radius: 8px;">
                        <img src="<?php echo e(asset($settings->cover_image)); ?>" width="300" alt="<?php echo e(__('lang.cover_image')); ?>">
                    </div>
                <?php else: ?>
                    <p><?php echo e(__('lang.no_cover')); ?></p>
                <?php endif; ?>
                <input type="file" name="cover_image" class="form-control mt-2" accept=".jpeg,.jpg,.png,.gif,.webp">
                <?php $__errorArgs = ['cover_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Social Media Links -->
            <div class="form-group mt-3">
                <label><?php echo e(__('lang.facebook_link')); ?></label>
                <input type="url" name="facebook" class="form-control" value="<?php echo e($settings->facebook ?? ''); ?>">
                <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group mt-3">
                <label><?php echo e(__('lang.linkedin_link')); ?></label>
                <input type="url" name="linkedin" class="form-control" value="<?php echo e($settings->linkedin ?? ''); ?>">
                <?php $__errorArgs = ['linkedin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group mt-3">
                <label><?php echo e(__('lang.youtube_link')); ?></label>
                <input type="url" name="youtube" class="form-control" value="<?php echo e($settings->youtube ?? ''); ?>">
                <?php $__errorArgs = ['youtube'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group mt-3">
                <label><?php echo e(__('lang.whatsapp_number')); ?></label>
                <input type="text" name="whatsapp" class="form-control" value="<?php echo e($settings->whatsapp ?? ''); ?>">
                <?php $__errorArgs = ['whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group mt-3">
                <label><?php echo e(__('lang.email_address')); ?></label>
                <input type="email" name="email" class="form-control" value="<?php echo e($settings->email ?? ''); ?>">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit" class="btn btn-primary mt-3"><?php echo e(__('lang.save_settings')); ?></button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\ictc\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>