<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card p-4">
        <h2><?php echo e(__('lang.edit_service')); ?></h2>
        <form action="<?php echo e(route('admin.services.update', $service->id)); ?>" method="POST">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label class="form-label"><?php echo e(__('lang.title_en')); ?></label>
                <input type="text" name="en_title" class="form-control" value="<?php echo e($service->en_title); ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label"><?php echo e(__('lang.title_ar')); ?></label>
                <input type="text" name="ar_title" class="form-control" value="<?php echo e($service->ar_title); ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label"><?php echo e(__('lang.description_en')); ?></label>
                <textarea name="en_description" class="form-control" required><?php echo e($service->en_description); ?></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label"><?php echo e(__('lang.description_ar')); ?></label>
                <textarea name="ar_description" class="form-control" required><?php echo e($service->ar_description); ?></textarea>
            </div>
            <button type="submit" class="btn btn-success"><?php echo e(__('lang.update')); ?></button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\ictc\resources\views/admin/services/edit.blade.php ENDPATH**/ ?>