<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold"><?php echo e(__('lang.services')); ?></h2>
            <a href="<?php echo e(route('admin.services.create')); ?>" class="btn btn-primary"><?php echo e(__('lang.add_service')); ?></a>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <div class="row">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-4 d-flex mt-3">
                    <div class="card shadow-sm border-0 w-100 h-100 d-flex flex-column">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title fw-bold"><?php echo e($service->en_title); ?> / <?php echo e($service->ar_title); ?></h5>
                            <p class="card-text text-muted flex-grow-1">
                                <?php echo e(Str::limit($service->en_description, 100)); ?> <br>
                                <?php echo e(Str::limit($service->ar_description, 100)); ?>

                            </p>
                            <div class="mt-auto d-flex justify-content-between">
                                <a href="<?php echo e(route('admin.services.edit', $service->id)); ?>" class="btn btn-warning"><?php echo e(__('lang.edit')); ?></a>
                                <form action="<?php echo e(route('admin.services.destroy', $service->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger" onclick="return confirm('<?php echo e(__('lang.confirm_delete')); ?>')"><?php echo e(__('lang.delete')); ?></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="mt-4 d-flex justify-content-center">
            <?php echo e($services->links('pagination::bootstrap-4')); ?> <!-- Bootstrap 4 Pagination -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\ictc\resources\views/admin/services/index.blade.php ENDPATH**/ ?>