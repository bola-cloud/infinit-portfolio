<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card p-4">
        <div class="card-header d-flex justify-content-between">
            <h1 class="mb-3"><?php echo e(__('lang.scopes_list')); ?></h1>
            <a href="<?php echo e(route('admin.scopes.create')); ?>" class="btn btn-primary mb-3"><?php echo e(__('lang.add_scope')); ?></a>
        </div>
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table class="table table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th><?php echo e(__('lang.ar_title')); ?></th>
                    <th><?php echo e(__('lang.en_title')); ?></th>
                    <th><?php echo e(__('lang.icon')); ?></th>
                    <th><?php echo e(__('lang.color')); ?></th>
                    <th><?php echo e(__('lang.actions')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $scopes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scope): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($scope->ar_title); ?></td>
                    <td><?php echo e($scope->en_title); ?></td>
                    <td><i class="<?php echo e($scope->icon); ?>"></i></td>
                    <td><span class="badge bg-<?php echo e($scope->color); ?>"><?php echo e($scope->color); ?></span></td>
                    <td>
                        <a href="<?php echo e(route('admin.scopes.edit', $scope->id)); ?>" class="btn btn-warning btn-sm"><?php echo e(__('lang.edit')); ?></a>
                        <form action="<?php echo e(route('admin.scopes.destroy', $scope->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger btn-sm" onclick="return confirm('<?php echo e(__('lang.confirm_delete')); ?>')"><?php echo e(__('lang.delete')); ?></button>
                        </form>
                        <!-- New Show Button -->
                        <a href="<?php echo e(route('admin.scopes.show', $scope->id)); ?>" class="btn btn-info btn-sm"><?php echo e(__('lang.show_projects')); ?></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\ictc\resources\views/admin/scopes/index.blade.php ENDPATH**/ ?>