<?php $__env->startSection('content'); ?>
    <!-- Hero Section -->
    <section class="head-video">
        <!-- Media Background -->
        <?php if($mainBanner): ?>

            <?php if($mainBanner->media_type == "video"): ?>
                <video autoplay muted loop style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover;">
                    <source src="https://www.qodra-egy.net/img/midea/My%20Video.mp4" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
            <?php elseif($mainBanner->media_type == "image"): ?>
                <img src="<?php echo e(asset('storage/' . $mainBanner->media_path)); ?>" alt="Banner Image" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover;">
            <?php endif; ?>
        <?php else: ?>
            <video autoplay muted loop style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover;">
                <source src="https://www.qodra-egy.net/img/midea/My%20Video.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        <?php endif; ?>

        <!-- Carousel Content Overlay -->
        <div class="overlay" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 10;">
            <div id="carouselExampleIndicators" class="carousel slide h-100" data-bs-ride="carousel">
                <!-- Carousel Items -->
                <div class="carousel-inner h-100">
                    <?php $__currentLoopData = $scopes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $scope): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-item <?php echo e($index == 0 ? 'active' : ''); ?> h-100">
                            <div class="container h-100">
                                <div class="row align-items-center h-100">
                                    <div class="col-8">
                                        <h1 class="text-light display-3 fw-bold text-center">
                                            <?php echo e($scope->title); ?>

                                        </h1>
                                        <p class="text-light text-center fs-4">
                                            <?php echo e($scope->description); ?>

                                        </p>
                                    </div>
                                    <div class="col-4 text-center">
                                        <i class="fa-solid <?php echo e($scope->icon); ?> fa-7x text-<?php echo e($scope->color); ?>"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Pagination Indicators -->
                <div class="carousel-indicators">
                    <?php $__currentLoopData = $scopes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $scope): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="<?php echo e($index); ?>" class="<?php echo e($index == 0 ? 'active' : ''); ?>" aria-label="Slide <?php echo e($index + 1); ?>"></button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Navigation Controls -->
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden"><?php echo e(__('lang.previous')); ?></span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden"><?php echo e(__('lang.next')); ?></span>
                </button>
            </div>
        </div>
    </section>

    <section id="gallery" style="padding: 50px 0; background-color: #f9f9f9;">
        <div class="container">
            <div class="section-title text-center" style="margin-bottom: 30px;">
                <h2 style="font-size: 2.5rem; font-weight: bold; color: #333;">
                    <strong> <?php echo e(__('lang.gallery_title')); ?> <?php echo e(__('lang.gallery_title_strong')); ?></strong>
                </h2>
                <p style="font-size: 1rem; color: #666;">
                    <?php echo e(__('lang.gallery_subtitle')); ?>

                </p>
            </div>
            <div class="row">
                <!-- Latest Image -->
                <div class="col-md-6">
                    <a href="<?php echo e(route('image-gallery')); ?>" class="d-block">
                        <div class="gallery-item position-relative mt-3">
                            <?php if($latestImage): ?>
                                <img src="<?php echo e(asset('storage/' . $latestImage->image_path)); ?>" class="img-fluid" alt="Latest Image">
                            <?php else: ?>
                                <img src="https://via.placeholder.com/600x400?text=No+Image+Available" class="img-fluid" alt="No Image Available">
                            <?php endif; ?>
                            <div class="overlay" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.6); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 1.5rem;">
                                <h2><?php echo e(__('lang.photo_gallery')); ?></h2>
                            </div>
                        </div>
                    </a>
                </div>

                <!-- Latest Video Thumbnail -->
                <div class="col-md-6">
                    <a href="<?php echo e(route('video-gallery')); ?>" class="d-block">
                        <div class="gallery-item position-relative mt-3">
                            <?php if($latestVideo): ?>
                                <video id="video-source" class="d-none">
                                    <source src="<?php echo e(asset('storage/' . $latestVideo->image_path)); ?>" type="video/mp4">
                                </video>
                                <img id="video-thumbnail" class="img-fluid" alt="Video Thumbnail">
                            <?php else: ?>
                                <img src="https://via.placeholder.com/600x400?text=No+Video+Available" class="img-fluid" alt="No Video Available">
                            <?php endif; ?>
                            <div class="overlay" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.6); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 1.5rem;">
                                <h2><?php echo e(__('lang.video_gallery')); ?></h2>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <section id="scope-of-work" style="padding: 60px 0; background-color: #f9f9f9;">
        <div class="container">
            <div class="text-center mb-5">
                <h2 style="font-size: 2.5rem; font-weight: bold; color: #333;">
                    <strong> <?php echo e(__('lang.scope_work_title')); ?> <?php echo e(__('lang.scope_work_title_strong')); ?></strong>
                </h2>
                <p style="font-size: 1.1rem; color: #666;">
                    <?php echo e(__('lang.scope_subtitle')); ?>

                </p>
            </div>

            <div class="row g-4">
                <?php $__currentLoopData = $scopes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scope): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="service-card text-center p-4 h-100" style="background: #fff; border: 1px solid #ddd; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); transition: transform 0.3s;">
                            <i class="ico icon-circled icon-bg<?php echo e($scope->color); ?> <?php echo e($scope->icon); ?> icon-4x mb-3"></i>
                            <h4 class="fw-bold mb-3" style="color: #333;">
                                <?php echo e(app()->getLocale() === 'ar' ? $scope->ar_title : $scope->en_title); ?>

                            </h4>
                            <p style="color: #555;">
                                <?php echo e(app()->getLocale() === 'ar' ? $scope->ar_description : $scope->en_description); ?>

                            </p>
                            <a href="<?php echo e(route('scope.projects', $scope->id)); ?>" class="btn btn-<?php echo e($scope->color); ?> mt-3">
                                <?php echo e(__('lang.show_projects')); ?>

                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <!-- About Us Section -->
    <section id="about-section" class="content">
        <div class="container">
            <div class="row">
                <!-- Image Section -->
                <div class="col-md-5 animate-fade-in-left">
                    <div class="about-image">
                        <img src="img/dummies/blog/img1.jpg" alt="<?php echo e(__('lang.about_title')); ?>" class="img-fluid" />
                    </div>
                </div>

                <!-- Text Content Section -->
                <div class="col-md-7 animate-fade-in-right">
                    <div class="about-text">
                        <h3><?php echo e(__('lang.about_title')); ?></h3>
                        <p>
                            <?php echo e(__('lang.about_description')); ?>

                        </p>
                        <div class="about-features">
                            <div class="feature-item">
                                <i class="icon-bullhorn"></i>
                                <span>
                                    <h5><?php echo e(__('lang.feature_1_title')); ?></h5>
                                    <p><?php echo e(__('lang.feature_1_description')); ?></p>
                                </span>
                            </div>
                            <div class="feature-item">
                                <i class="icon-sitemap"></i>
                                <span>
                                    <h5><?php echo e(__('lang.feature_2_title')); ?></h5>
                                    <p><?php echo e(__('lang.feature_2_description')); ?></p>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php
        $icons = [
            'fa-award',        // Proven Expertise
            'fa-cogs',         // Customized Solutions
            'fa-lightbulb',    // Innovative Approach
            'fa-layer-group',  // Comprehensive Services
            'fa-leaf',         // Focus on Sustainability
            'fa-user-check',   // Client-Centric Philosophy
            'fa-chart-line',   // Track Record of Success
            'fa-star'          // Commitment to Excellence
        ];
    ?>
    <!-- Why ICTC Section -->
    <section id="why-ictc" style="padding: 50px 0; background-color: #f5f5f5;">
        <div class="container">
            <div class="text-center mb-5">
                <h2 style="font-size: 2.5rem; font-weight: bold; color: #333;">
                    <strong> <?php echo e(__('lang.why_ictc_title')); ?> <?php echo e(__('lang.why_ictc_title_strong')); ?></strong>
                </h2>
                <p style="font-size: 1.1rem; color: #666;">
                    <?php echo e(__('lang.why_ictc_subtitle')); ?>

                </p>
            </div>
            <div class="row text-center">
                <?php for($i = 1; $i <= 8; $i++): ?>
                    <div class="col-md-3 mb-4">
                        <div class="feature-box h-100 d-flex flex-column justify-content-between p-4" style="background: #fff; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
                            <i class="fa <?php echo e($icons[$i-1]); ?> fa-3x text-primary mb-3"></i>
                            <h4 class="mb-2" style="font-weight: bold;">
                                <?php echo e(__('lang.feature_' . $i . '_title')); ?>

                            </h4>
                            <p style="font-size: 0.9rem; color: #555;">
                                <?php echo e(__('lang.feature_' . $i . '_description')); ?>

                            </p>
                        </div>
                    </div>
                <?php endfor; ?>
            </div>
        </div>
    </section>

    <section class="news-section">
        <div class="container">
            <div class="row">
            <div class="col-12 text-center mb-2">
                <h2 style="font-size: 2.5rem; font-weight: bold; color: #333;">
                    <strong> <?php echo e(__('lang.latest_news_title')); ?> <?php echo e(__('lang.latest_news_title_strong')); ?></strong>
                </h2>
            </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <?php if(!empty($news)): ?>
                        <div class="card news-card p-2">
                            <div class="news-images">
                                <?php if(!empty($news->image1_path)): ?>
                                    <img src="<?php echo e(asset('storage/' . $news->image1_path)); ?>" alt="<?php echo e(__('lang.news_title')); ?>">
                                <?php else: ?>
                                    <img src="https://via.placeholder.com/300x200?text=No+Image+Available" alt="No Image Available">
                                <?php endif; ?>

                                <?php if(!empty($news->image2_path)): ?>
                                    <img src="<?php echo e(asset('storage/' . $news->image2_path)); ?>" alt="<?php echo e(__('lang.news_title')); ?>">
                                <?php else: ?>
                                    <img src="https://via.placeholder.com/300x200?text=No+Image+Available" alt="No Image Available">
                                <?php endif; ?>
                            </div>
                            <div class="card-body news-card-body">
                                <h3 class="news-card-title">
                                    <?php echo e(app()->getLocale() === 'ar' ? ($news->ar_title ?? __('lang.no_title_available')) : ($news->en_title ?? __('lang.no_title_available'))); ?>

                                </h3>
                                <p class="news-card-text">
                                    <?php echo e(app()->getLocale() === 'ar' ? ($news->ar_subtitle ?? __('lang.no_subtitle_available')) : ($news->en_subtitle ?? __('lang.no_subtitle_available'))); ?>

                                </p>
                                <?php if(!empty($news->id)): ?>
                                    <a href="<?php echo e(route('news-details', $news->id)); ?>" class="news-read-more">
                                        <?php echo e(__('lang.read_more')); ?> &raquo;
                                    </a>
                                <?php else: ?>
                                    <span class="news-read-more disabled" style="color: #aaa; cursor: not-allowed;">
                                        <?php echo e(__('lang.no_details_available')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <p><?php echo e(__('lang.no_news_available')); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>


    

    

    <section id="partners" class="partners-section">
        <div class="container">
            <div class="title-container">
                <h3 class="title">
                    <strong><?php echo e(__('lang.partners_title')); ?> <?php echo e(__('lang.partners_title_strong')); ?></strong>
                </h3>
            </div>
            <div class="swiper partners-slider-unique">
                <div class="swiper-wrapper">
                    <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide">
                            <img src="<?php echo e(asset($partner->image_path)); ?>" alt="Partner">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <!-- Include Video Thumbnail Generation Script -->
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            let video = document.getElementById("video-source");
            if (video) {
                let canvas = document.createElement("canvas");
                let context = canvas.getContext("2d");
                let thumbnail = document.getElementById("video-thumbnail");

                video.addEventListener("loadeddata", function() {
                    video.currentTime = 2; // Capture at 2 seconds
                });

                video.addEventListener("seeked", function() {
                    canvas.width = video.videoWidth / 2;
                    canvas.height = video.videoHeight / 2;
                    context.drawImage(video, 0, 0, canvas.width, canvas.height);
                    thumbnail.src = canvas.toDataURL("image/png"); // Convert to base64
                });

                video.load();
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\ictc\resources\views/front/home.blade.php ENDPATH**/ ?>