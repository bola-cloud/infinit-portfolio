<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card p-4">
        <h1 class="mb-3"><?php echo e(__('lang.messages_list')); ?></h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table class="table table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th><?php echo e(__('lang.name')); ?></th>
                    <th><?php echo e(__('lang.email')); ?></th>
                    <th><?php echo e(__('lang.message')); ?></th>
                    <th><?php echo e(__('lang.status')); ?></th>
                    <th><?php echo e(__('lang.actions')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($message->name); ?></td>
                    <td><?php echo e($message->email); ?></td>
                    <td><?php echo e(Str::limit($message->message, 50)); ?></td>
                    <td>
                        <span class="badge <?php echo e($message->is_read ? 'bg-success' : 'bg-warning'); ?>">
                            <?php echo e($message->is_read ? __('lang.read') : __('lang.unread')); ?>

                        </span>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.messages.show', $message->id)); ?>" class="btn btn-info btn-sm"><?php echo e(__('lang.view')); ?></a>
                        <form action="<?php echo e(route('admin.messages.destroy', $message->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger btn-sm" onclick="return confirm('<?php echo e(__('lang.confirm_delete')); ?>')"><?php echo e(__('lang.delete')); ?></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php echo e($messages->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\ictc\resources\views/admin/messages/index.blade.php ENDPATH**/ ?>