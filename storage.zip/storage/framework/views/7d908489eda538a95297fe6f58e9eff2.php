<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" dir="<?php echo e(app()->getLocale() === 'ar' ? 'rtl' : 'ltr'); ?>">

<head>
    <meta charset="utf-8">
    <title>ICTC</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Your page description here" />
    <meta name="author" content="" />

    <!-- css -->
    <link href="https://fonts.googleapis.com/css?family=Handlee|Open+Sans:300,400,600,700,800" rel="stylesheet">
    
    <link href="<?php echo e(asset('css/flexslider.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/prettyPhoto.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/camera.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/jquery.bxslider.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css">

    <!-- Theme skin -->
    <link href="<?php echo e(asset('color/default.css')); ?>" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Fav and touch icons -->
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo e(asset('ico/apple-touch-icon-144-precomposed.png')); ?>" />
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo e(asset('ico/apple-touch-icon-114-precomposed.png')); ?>" />
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo e(asset('ico/apple-touch-icon-72-precomposed.png')); ?>" />
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(asset('ico/apple-touch-icon-57-precomposed.png')); ?>" />
    <link rel="shortcut icon" href="<?php echo e(asset('img/ictc.jpeg')); ?>" />
    <!-- Add Google Fonts -->
    <?php if(app()->getLocale() === 'ar'): ?>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600&display=swap" rel="stylesheet">
    <?php else: ?>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <?php endif; ?>

    <style>
        body {
            font-family: <?php echo e(app()->getLocale() === 'ar' ? "'Tajawal', sans-serif" : "'Roboto', sans-serif"); ?>;
            direction: <?php echo e(app()->getLocale() === 'ar' ? 'rtl' : 'ltr'); ?>;
            text-align: <?php echo e(app()->getLocale() === 'ar' ? 'right' : 'left'); ?>;
            font-size: <?php echo e(app()->getLocale() === 'ar' ? '1.1rem' : '1rem'); ?>;
        }

        h1, h2, h3, h4, h5, h6 {
            font-weight: <?php echo e(app()->getLocale() === 'ar' ? '700' : '500'); ?>;
            letter-spacing: <?php echo e(app()->getLocale() === 'ar' ? '0.5px' : 'normal'); ?>;
            word-spacing: <?php echo e(app()->getLocale() === 'ar' ? '2px' : 'normal'); ?>;
            font-size: <?php echo e(app()->getLocale() === 'ar' ? '1.2em' : '1em'); ?>;
        }

        p {
            font-weight: <?php echo e(app()->getLocale() === 'ar' ? '500' : '400'); ?>;
            letter-spacing: <?php echo e(app()->getLocale() === 'ar' ? '0.5px' : 'normal'); ?>;
            line-height: 1.8;
            word-spacing: <?php echo e(app()->getLocale() === 'ar' ? '1.5px' : 'normal'); ?>;
            font-size: <?php echo e(app()->getLocale() === 'ar' ? '1.05rem' : '1rem'); ?>;
        }
    </style>

</head>

<body>

    <div id="wrapper">
        <!-- start header -->
        <header>
            <div class="container">
                <div class="row nomargin">
                    <div class="col-md-3 d-flex justify-content-center">
                        <div class="logo">
                            <a href="<?php echo e(route('home')); ?>" class="d-flex">
                                <img src="<?php echo e(asset($settings->logo ?? 'img/white logo.png')); ?>" alt="Logo" style="max-height: 60px;">
                            </a>
                        </div>
                    </div>
                    <div class="col-md-8 d-none d-md-flex">
                        <!-- Regular Navigation (Visible on Desktop) -->
                        <div class="navbar navbar-static-top navigation">
                            <nav>
                                <ul class="nav topnav" style="display: flex; gap: 10px; list-style: none; padding: 0; margin: 0;">
                                    
                                    <li class="dropdown <?php echo e(request()->routeIs('about') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('about')); ?>" class="nav-btn <?php echo e(request()->routeIs('about') ? 'btn-highlight' : ''); ?>">
                                            <?php echo e(__('lang.about')); ?>

                                        </a>
                                    </li>
                                    <li class="dropdown <?php echo e(request()->routeIs('services') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('services')); ?>" class="nav-btn <?php echo e(request()->routeIs('services') ? 'btn-highlight' : ''); ?>">
                                            <?php echo e(__('lang.services')); ?>

                                        </a>
                                    </li>
                                    <li class="dropdown <?php echo e(request()->routeIs('all-projects') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('all-projects')); ?>" class="nav-btn <?php echo e(request()->routeIs('all-projects') ? 'btn-highlight' : ''); ?>">
                                            <?php echo e(__('lang.projects')); ?>

                                        </a>
                                    </li>
                                    <li class="dropdown <?php echo e(request()->routeIs(['image-gallery', 'video-gallery','latest.news']) ? 'active' : ''); ?>">
                                        <a href="#" class="nav-btn"><?php echo e(__('lang.media')); ?> <i class="icon-angle-down"></i></a>
                                        <ul class="dropdown-menu" style="top: 60% !important;">
                                            <li><a href="<?php echo e(route('image-gallery')); ?>"><?php echo e(__('lang.photos_gallery')); ?></a></li>
                                            <li><a href="<?php echo e(route('video-gallery')); ?>"><?php echo e(__('lang.videos_gallery')); ?></a></li>
                                            <li><a href="<?php echo e(route('latest.news')); ?>"><?php echo e(__('lang.latest_news')); ?></a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown <?php echo e(request()->routeIs('partners') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('partners')); ?>" class="nav-btn"><?php echo e(__('lang.partners')); ?></a>
                                    </li>
                                    <li class="dropdown <?php echo e(request()->routeIs('contact') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('contact')); ?>" class="nav-btn"><?php echo e(__('lang.contact')); ?></a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>

                    <div class="col-md-1 d-flex align-items-center justify-content-end lang">
                        <!-- Language Dropdown -->
                        <div class="dropdown">
                            <button
                                class="btn btn-light dropdown-toggle p-2"
                                type="button"
                                id="languageDropdown"
                                data-bs-toggle="dropdown"
                                aria-expanded="false"
                                style="border-radius: 12px; min-width: 80px;"
                            >
                                <i class="fa-solid fa-globe"></i>
                                <?php echo e(App::getLocale() == 'ar' ? 'AR' : 'EN'); ?>

                            </button>
                            <ul
                                class="dropdown-menu dropdown-menu-end custom-dropdown"
                                aria-labelledby="languageDropdown"
                            >
                                <li>
                                    <a
                                        class="dropdown-item"
                                        href="<?php echo e(LaravelLocalization::getLocalizedURL('en')); ?>"
                                    >
                                        English
                                    </a>
                                </li>
                                <li>
                                    <a
                                        class="dropdown-item"
                                        href="<?php echo e(LaravelLocalization::getLocalizedURL('ar')); ?>"
                                    >
                                        العربية
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- Hamburger Menu for Mobile -->
                    <div class="col-md-1 d-flex align-items-center justify-content-end d-md-none">
                        <div class="hamburger-menu">
                            <button class="hamburger-btn">
                                <i class="fa fa-bars"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Side Navigation (Visible on Mobile) -->
            <div class="side-nav">
                <nav>
                    <ul class="nav topnav">
                        
                        <li class="dropdown <?php echo e(request()->routeIs('about') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('about')); ?>"><?php echo e(__('lang.about')); ?></a>
                        </li>
                        <li class="dropdown <?php echo e(request()->routeIs('services') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('services')); ?>"><?php echo e(__('lang.services')); ?></a>
                        </li>
                        <li class="dropdown <?php echo e(request()->routeIs('all-projects') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('all-projects')); ?>"><?php echo e(__('lang.projects')); ?></a>
                        </li>
                        <li class="dropdown <?php echo e(request()->routeIs(['image-gallery', 'video-gallery','latest.news']) ? 'active' : ''); ?>">
                            <a href="#" class="nav-btn"><?php echo e(__('lang.media')); ?> <i class="icon-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo e(route('image-gallery')); ?>"><?php echo e(__('lang.photos_gallery')); ?></a></li>
                                <li><a href="<?php echo e(route('video-gallery')); ?>"><?php echo e(__('lang.videos_gallery')); ?></a></li>
                                <li><a href="<?php echo e(route('latest.news')); ?>"><?php echo e(__('lang.latest_news')); ?></a></li>
                            </ul>
                        </li>
                        <li class="dropdown <?php echo e(request()->routeIs('partners') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('partners')); ?>"><?php echo e(__('lang.partners')); ?></a>
                        </li>
                        <li class="dropdown <?php echo e(request()->routeIs('contact') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('contact')); ?>"><?php echo e(__('lang.contact')); ?></a>
                        </li>
                        <div>
                            <!-- Language Dropdown -->
                            <div class="dropdown">
                                <button class="btn btn-light dropdown-toggle p-2" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fa-solid fa-globe"></i> <?php echo e(App::getLocale() == 'ar' ? 'AR' : 'EN'); ?>

                                </button>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown" style="border-radius: 12px; min-width: 100px;">
                                    <li>
                                        <a
                                            class="dropdown-item"
                                            href="<?php echo e(LaravelLocalization::getLocalizedURL('en')); ?>"
                                        >
                                            English
                                        </a>
                                    </li>
                                    <li>
                                        <a
                                            class="dropdown-item"
                                            href="<?php echo e(LaravelLocalization::getLocalizedURL('ar')); ?>"
                                        >
                                            العربية
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </ul>
                </nav>
            </div>
        </header>

        <!-- end header -->
        <div class="spinner-overlay" id="loadingSpinner">
            <div class="grow-pulse"></div>
        </div>
        <div>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <div class="share-container">
            <!-- Share Icon -->
            <button class="share__button">
                <i class="fa-solid fa-share-nodes"></i>
            </button>

            <!-- Social Icons -->
            <ul class="share__icons">
                <!-- Facebook -->
                <li style="--rotate: -18deg;">
                    <a href="<?php echo e(!empty($settings->facebook) ? $settings->facebook : '#'); ?>" target="_blank" style="background-color: #1877F2;">
                        <i class="fa-brands fa-facebook-f"></i>
                    </a>
                </li>

                <!-- LinkedIn -->
                <li style="--rotate: 27deg;">
                    <a href="<?php echo e(!empty($settings->linkedin) ? $settings->linkedin : '#'); ?>" target="_blank" style="background-color: #0077b5;">
                        <i class="fa-brands fa-linkedin"></i>
                    </a>
                </li>

                <!-- WhatsApp -->
                <li style="--rotate: 72deg;">
                    <a href="<?php echo e(!empty($settings->whatsapp) ? 'https://wa.me/' . $settings->whatsapp : '#'); ?>" target="_blank" style="background-color: #25D366;">
                        <i class="fa-brands fa-whatsapp"></i>
                    </a>
                </li>

                <!-- YouTube -->
                <li style="--rotate: 117deg;">
                    <a href="<?php echo e(!empty($settings->youtube) ? $settings->youtube : '#'); ?>" target="_blank" style="background-color: #FF0000;">
                        <i class="fa-brands fa-youtube"></i>
                    </a>
                </li>
            </ul>
        </div>


        <footer style="background-color:#1a2333; color: #fff; padding: 40px 0;">
            <div class="container">
                <div class="row d-flex justify-content-between align-items-center">

                    <!-- Left Column: Logo and Description -->
                    <div class="col-md-4">
                        <div>
                            <a href="<?php echo e(route('dashboard')); ?>">
                                <img src="<?php echo e(asset($settings->logo ?? 'img/white logo.png')); ?>" alt="Logo" style="max-height: 60px; margin-bottom: 15px;">
                            </a>
                            <p style="margin: 0;">
                                <?php echo e(__('lang.company_name')); ?>

                            </p>
                        </div>
                    </div>

                    <!-- Center Column: Useful Links -->
                    

                    <!-- Right Column: Contact Info -->
                    <div class="col-md-4">
                        <h5 style="color: #fff; font-weight: bold;"><?php echo e(__('lang.contact')); ?></h5>
                        <p>
                            <i class="fa fa-phone"></i> <?php echo e(__('lang.support')); ?>&nbsp; :&nbsp; 020000000<br>
                            <i class="fa fa-envelope"></i> <?php echo e(__('lang.email')); ?>&nbsp; : &nbsp;contact@ictc-egy.com
                        </p>
                        <div style="display: flex; gap: 10px;">
                            <!-- Facebook -->
                            <a href="<?php echo e(!empty($settings->facebook) ? $settings->facebook : '#'); ?>" target="_blank"
                                style="color: #fff; background-color: #2f2f2f; border-radius: 50%; width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;">
                                <i class="fa-brands fa-facebook"></i>
                            </a>

                            <!-- WhatsApp -->
                            <a href="<?php echo e(!empty($settings->whatsapp) ? 'https://wa.me/' . $settings->whatsapp : '#'); ?>" target="_blank"
                                style="color: #fff; background-color: #2f2f2f; border-radius: 50%; width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;">
                                <i class="fa-brands fa-whatsapp"></i>
                            </a>

                            <!-- Email -->
                            <a href="<?php echo e(!empty($settings->email) ? 'mailto:' . $settings->email : '#'); ?>" target="_blank"
                                style="color: #fff; background-color: #2f2f2f; border-radius: 50%; width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;">
                                <i class="fa fa-envelope"></i>
                            </a>

                            <!-- LinkedIn -->
                            <a href="<?php echo e(!empty($settings->linkedin) ? $settings->linkedin : '#'); ?>" target="_blank"
                                style="color: #fff; background-color: #2f2f2f; border-radius: 50%; width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;">
                                <i class="fa-brands fa-linkedin"></i>
                            </a>

                            <!-- YouTube -->
                            <a href="<?php echo e(!empty($settings->youtube) ? $settings->youtube : '#'); ?>" target="_blank"
                                style="color: #fff; background-color: #2f2f2f; border-radius: 50%; width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;">
                                <i class="fa-brands fa-youtube"></i>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Footer Bottom -->
                <div style="border-top: 1px solid #333; margin-top: 20px; padding-top: 15px; text-align: center;">
                    
                    <p style="margin: 5px 0 0; color: #ccc;">
                        <?php echo e(__('lang.developed_by')); ?>

                        <a href="https://wa.me/201555622169" target="_blank" style="color: #25D366; text-decoration: none;">
                            <strong>Eng: Bola Eshaq</strong>
                        </a>
                    </p>
                </div>
            </div>
        </footer>

    </div>
    <a href="#" class="scrollup"><i class="icon-angle-up icon-square icon-bglight icon-2x active"></i></a>

    <!-- javascript
      ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap 5 JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script src="<?php echo e(asset('js/modernizr.custom.js')); ?>"></script>
    <script src="<?php echo e(asset('js/toucheffects.js')); ?>"></script>
    <script src="<?php echo e(asset('js/google-code-prettify/prettify.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.bxslider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/camera/camera.js')); ?>"></script>
    <script src="<?php echo e(asset('js/camera/setting.js')); ?>"></script>

    <script src="<?php echo e(asset('js/jquery.prettyPhoto.js')); ?>"></script>
    <script src="<?php echo e(asset('js/portfolio/jquery.quicksand.js')); ?>"></script>
    <script src="<?php echo e(asset('js/portfolio/setting.js')); ?>"></script>

    <script src="<?php echo e(asset('js/jquery.flexslider.js')); ?>"></script>
    <script src="<?php echo e(asset('js/animate.js')); ?>"></script>
    <script src="<?php echo e(asset('js/inview.js')); ?>"></script>

    <!-- Template Custom JavaScript File -->
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>


    <script>
        // Initialize the thumbs gallery first
        document.addEventListener("DOMContentLoaded", () => {
            const swiperThumbs = new Swiper(".thumbs-gallery", {
                spaceBetween: 10,
                slidesPerView: 5,
                freeMode: true,
                watchSlidesVisibility: true,
                watchSlidesProgress: true,
            });

            // Initialize the main gallery, linking to the thumbs gallery
            const swiperMain = new Swiper(".main-gallery", {
                spaceBetween: 10,
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
                thumbs: {
                    swiper: swiperThumbs, // Link the thumbs swiper here
                },
            });
        });

        // Partners slider
        document.addEventListener("DOMContentLoaded", () => {
            const partnersSwiper = new Swiper(".partners-slider-unique", {
            slidesPerView: 5, // Number of visible logos
            spaceBetween: 20, // Space between slides
            loop: true, // Continuous looping
            autoplay: {
                delay: 0, // No delay for continuous scroll
                disableOnInteraction: false,
            },
            speed: 3000, // Adjust speed for smoother scrolling
            allowTouchMove: false, // Disable manual sliding
            breakpoints: {
                768: {
                slidesPerView: 5, // Adjust for tablet
                },
                480: {
                slidesPerView: 2, // Adjust for mobile
                },
            },
            });
        });

        // Share button toggle
        document.addEventListener("DOMContentLoaded", () => {
            const shareButton = document.querySelector(".share__button");
            const shareContainer = document.querySelector(".share-container");

            if (shareButton && shareContainer) {
                shareButton.addEventListener("click", () => {
                    shareContainer.classList.toggle("active");
                });
            }
        });

        // Header scroll effect
        document.addEventListener("DOMContentLoaded", () => {
            const header = document.querySelector("header");
            window.addEventListener("scroll", () => {
                if (window.scrollY > 50) {
                    header.classList.add("scrolled");
                } else {
                    header.classList.remove("scrolled");
                }
            });
        });

        // Text slider
        document.addEventListener("DOMContentLoaded", () => {
            const textSwiper = new Swiper(".text-slider", {
                loop: true,
                autoplay: {
                    delay: 4000, // Auto-slide every 4 seconds
                    disableOnInteraction: false,
                },
                effect: "fade", // Smooth fade effect
                pagination: {
                    el: ".swiper-pagination",
                    clickable: true,
                    bulletClass: "swiper-pagination-bullet",
                    bulletActiveClass: "swiper-pagination-bullet-active",
                },
                allowTouchMove: false, // Disable manual swipe
            });
        });

        // Photo Gallery Lightbox
        document.addEventListener('DOMContentLoaded', () => {
            // Initialize Swiper
            const swiper = new Swiper('.swiper-container', {
                navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev',
                },
            });

            // Open modal and navigate to the clicked image
            const galleryItems = document.querySelectorAll('.gallery-item');
            const modal = document.getElementById('lightbox-modal');
            const modalInstance = new bootstrap.Modal(modal);

            galleryItems.forEach((item, index) => {
                item.addEventListener('click', (e) => {
                    e.preventDefault();
                    swiper.slideTo(index, 0); // Go to the clicked image
                    modalInstance.show(); // Open the modal
                });
            });
        });

        // Show spinner on page load
        document.addEventListener('DOMContentLoaded', () => {
            const spinner = document.getElementById('loadingSpinner');
            spinner.classList.add('active');

            // Hide spinner after page fully loads
            window.addEventListener('load', () => {
                spinner.classList.remove('active');
            });

            // Handle route changes for Single Page Applications (SPAs)
            if (window.history.pushState) {
                document.addEventListener('click', (e) => {
                    const target = e.target.closest('a'); // Find the closest anchor tag
                    if (
                        target &&
                        target.href &&
                        target.target !== '_blank' &&
                        target.getAttribute('href') !== '#' &&
                        target.getAttribute('href') !== ''
                    ) {
                        e.preventDefault(); // Prevent default navigation
                        spinner.classList.add('active'); // Show spinner

                        // Simulate loading (replace this part with your actual page navigation logic)
                        setTimeout(() => {
                            window.location.href = target.href; // Perform navigation
                        }, 1000); // Adjust the delay as needed
                    }
                });
            }

            // Hide spinner on popstate (back/forward button)
            window.addEventListener('popstate', () => {
                spinner.classList.remove('active');
            });
        });


        // Toggle the side navigation
        $(document).ready(function () {
            // Toggle the side navigation
            $(".hamburger-btn").on("click", function () {
                $(".side-nav").toggleClass("open");
            });

            // Close side navigation when clicking outside
            $(document).on("click", function (e) {
                if (!$(e.target).closest(".side-nav, .hamburger-btn").length) {
                    $(".side-nav").removeClass("open");
                }
            });
        });

    </script>
    <?php echo $__env->yieldPushContent('js'); ?>
</body>
</html>
<?php /**PATH C:\Bola\ictc\resources\views/layouts/app.blade.php ENDPATH**/ ?>