

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card p-4">
        <div class="card-header d-flex justify-content-between">
            <h1 class="mb-3"><?php echo e(__('lang.banner_management')); ?></h1>
            <a href="<?php echo e(route('admin.main_banners.create')); ?>" class="btn btn-primary mb-3"><?php echo e(__('lang.create_banner')); ?></a>
        </div>
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table class="table">
            <thead>
                <tr>
                    <th><?php echo e(__('lang.media')); ?></th>
                    <th><?php echo e(__('lang.type')); ?></th>
                    <th><?php echo e(__('lang.flag')); ?></th>
                    <th><?php echo e(__('lang.actions')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <?php if($banner->media_type == 'image'): ?>
                            <img src="<?php echo e(asset('storage/' . $banner->media_path)); ?>" alt="Banner Image" width="100">
                        <?php else: ?>
                            <video src="<?php echo e(asset('storage/' . $banner->media_path)); ?>" controls width="100"></video>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($banner->media_type); ?></td>
                    <td><?php echo e($banner->flag ? __('lang.yes') : __('lang.no')); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.main_banners.edit', $banner->id)); ?>" class="btn btn-warning"><?php echo e(__('lang.edit')); ?></a>
                        <form action="<?php echo e(route('admin.main_banners.destroy', $banner->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger"><?php echo e(__('lang.delete')); ?></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4"><?php echo e(__('lang.no_banners_found')); ?></td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\ictc\resources\views/admin/main_banners/index.blade.php ENDPATH**/ ?>