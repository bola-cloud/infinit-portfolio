<?php $__env->startSection('content'); ?>

<!-- Address Section -->
<section class="address" style="background: linear-gradient(60deg, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('<?php echo e(asset($settings->cover_image ?? 'https://www.qodra-egy.net/img/about/ab_4.jpg')); ?>'); background-size: cover; background-position: center;">
    <div class="container">
        <div class="col-lg-12 text-center">
            <h3 class="address-h3">
                <?php echo e(__('lang.partners_heading')); ?>

            </h3>
        </div>
    </div>
</section>

<section class="partners-section">
    <div class="container">
        <!-- Title -->
        <div class="text-center mb-4">
            <h3 class="title">
                <?php echo e(__('lang.partners_section_title')); ?> <strong><?php echo e(__('lang.partners_section_strong')); ?></strong>
            </h3>
        </div>

        <!-- Dynamic Partners Section -->
        <div class="row">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 mb-5">
                    <h4 class="category-title text-center mb-3">
                        <?php echo e(app()->getLocale() === 'ar' ? $category->ar_name : $category->en_name); ?>

                    </h4>
                    <div class="row">
                        <?php $__currentLoopData = $category->partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3 col-sm-6 mb-4">
                                <div class="card">
                                    <img src="<?php echo e(asset($partner->image_path)); ?>" class="card-img-top" alt="Partner">
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\ictc\resources\views/front/partners.blade.php ENDPATH**/ ?>