<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card p-4">
        <div class="card-header d-flex justify-content-between">
            <h1 class="mb-3"><?php echo e(__('lang.user_management')); ?></h1>
            <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary"><?php echo e(__('lang.create_user')); ?></a>
        </div>
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <table class="table">
            <thead>
                <tr>
                    <th><?php echo e(__('lang.name')); ?></th>
                    <th><?php echo e(__('lang.email')); ?></th>
                    <th><?php echo e(__('lang.category')); ?></th>
                    <th><?php echo e(__('lang.actions')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->category); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-warning"><?php echo e(__('lang.edit')); ?></a>
                        <?php if($user->id !== auth()->id()): ?>
                            <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger" onclick="return confirm('<?php echo e(__('lang.confirm_delete')); ?>')">
                                    <?php echo e(__('lang.delete')); ?>

                                </button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4"><?php echo e(__('lang.no_users_found')); ?></td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\ictc\resources\views/admin/users/index.blade.php ENDPATH**/ ?>