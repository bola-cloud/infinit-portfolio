<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card p-4">
        <div class="card-header d-flex justify-content-between">
            <h1 class="mb-3"><?php echo e(__('lang.partners_list')); ?></h1>
            <a href="<?php echo e(route('admin.partners.create')); ?>" class="btn btn-primary mb-3"><?php echo e(__('lang.add_partner')); ?></a>
        </div>
        <table class="table">
            <thead>
                <tr>
                    <th><?php echo e(__('lang.category')); ?></th>
                    <th><?php echo e(__('lang.image')); ?></th>
                    <th><?php echo e(__('lang.actions')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>

                        <?php if(!empty($partner->categories) && $partner->categories instanceof \App\Models\PartnerCategory): ?>
                            <?php echo e(app()->getLocale() == 'ar' ? $partner->categories->ar_name : $partner->categories->en_name); ?>

                        <?php else: ?>
                            <span class="text-muted"><?php echo e(__('lang.no_category')); ?></span>
                        <?php endif; ?>
                    </td>
                    <td><img src="<?php echo e(asset($partner->image_path)); ?>" width="80"></td>
                    <td>
                        <a href="<?php echo e(route('admin.partners.edit', $partner->id)); ?>" class="btn btn-warning btn-sm"><?php echo e(__('lang.edit')); ?></a>
                        <form action="<?php echo e(route('admin.partners.destroy', $partner->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger btn-sm" onclick="return confirm('<?php echo e(__('lang.confirm_delete')); ?>')"><?php echo e(__('lang.delete')); ?></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\ictc\resources\views/admin/partners/index.blade.php ENDPATH**/ ?>