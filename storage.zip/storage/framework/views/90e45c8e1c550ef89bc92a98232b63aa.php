

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card p-4">
        <div class="card-header d-flex justify-content-between">
            <h1 class="mb-3"><?php echo e(__('lang.news_management')); ?></h1>
            <a href="<?php echo e(route('admin.news.create')); ?>" class="btn btn-primary mb-3"><?php echo e(__('lang.create_news')); ?></a>
        </div>
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table class="table">
            <thead>
                <tr>
                    <th><?php echo e(__('lang.image')); ?></th>
                    <th><?php echo e(__('lang.title')); ?></th>
                    <th><?php echo e(__('lang.head')); ?></th>
                    <th><?php echo e(__('lang.flag')); ?></th>
                    <th><?php echo e(__('lang.actions')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <!-- Display the first image -->
                    <td>
                        <?php if($item->image1_path): ?>
                            <img src="<?php echo e(asset('storage/' . $item->image1_path)); ?>" alt="News Image" width="100" class="rounded">
                        <?php else: ?>
                            <span><?php echo e(__('lang.no_image')); ?></span>
                        <?php endif; ?>
                    </td>

                    <!-- Display the localized title -->
                    <td><?php echo e(app()->getLocale() === 'ar' ? $item->ar_title : $item->en_title); ?></td>

                    <!-- Display the localized head -->
                    <td><?php echo e(app()->getLocale() === 'ar' ? $item->ar_head : $item->en_head); ?></td>

                    <!-- Display the flag status -->
                    <td><?php echo e($item->flag ? __('lang.yes') : __('lang.no')); ?></td>

                    <!-- Action buttons -->
                    <td>
                        <a href="<?php echo e(route('admin.news.edit', $item->id)); ?>" class="btn btn-warning"><?php echo e(__('lang.edit')); ?></a>
                        <form action="<?php echo e(route('admin.news.destroy', $item->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger"><?php echo e(__('lang.delete')); ?></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5"><?php echo e(__('lang.no_news_found')); ?></td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\ictc\resources\views/admin/news/index.blade.php ENDPATH**/ ?>